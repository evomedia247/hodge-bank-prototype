

describe("FeeDetailsControllerTest", function() {
  var controller;

  beforeEach(function() {
    controller = FeeDetailsController;
  });

  it("should start with no errors", function() {
    controller.init();
    expect(true).toBeTruthy();
  });


});
